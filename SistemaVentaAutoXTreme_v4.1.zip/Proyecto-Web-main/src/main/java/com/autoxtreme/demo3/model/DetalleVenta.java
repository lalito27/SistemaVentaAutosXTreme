package com.autoxtreme.demo3.model;

public class DetalleVenta {
    private int idventa;
    private int idcliente;
    private int idempleado;
    private int idcarro;
    private int cantidad;
    private String numserie;
    private String fechaemision;
    private double monto;
}
